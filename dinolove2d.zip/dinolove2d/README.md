## Notes

A fan remake of Google DIno in Love2D

Ready To Run

## Controls

| Button | Action |
|--|--| 
|D-pad up|jump|
|D-pad down|duck|
|A| jump|
|X| show hitboxes|


